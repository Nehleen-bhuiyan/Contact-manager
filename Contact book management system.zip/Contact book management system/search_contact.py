import csv               
def search_contact():
    print("Coose search option")
    print("1.Search by name")
    print("2.Search by email")
    print("3.Search by phone number")
    print("4.Search by address")
    choice=input("Enter your choice:")
    if choice=="1":
        search_input=input("Enter name of contact you want to search:")
        search_string="name"
        search(search_string,search_input)
    elif choice=="2":
        search_input=input("Enter email of contact you want to search:")
        search_string="email"
        search(search_string,search_input)
    elif choice=="3":
        search_input=input("Enter phone number of contact you want to search:")
        search_string="phone_num"
        search(search_string,search_input)
    elif choice=="4":
        search_input=input("Enter address of contact you want to search:")
        search_string="address"
        search(search_string,search_input)
    
    
    
def search(search_string,search_input):
    with open("contact.csv","r") as file:
        content =csv.DictReader(file)
        for row in content:
            if row[search_string]==search_input:
                print(f"Name:{row["name"]} |Email:{row["email"]} |Phone number:{row["phone_num"]} |Address:{row["address"]}")
                break
        else:
            print("Contact not found")