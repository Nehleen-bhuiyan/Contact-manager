import csv
def save_contact(contact):
    if contact!=[]:
        
        with open ("contact.csv","a") as file:
            if file.tell()==0:
                line ="name,email,phone_num,address\n"
                file.write(line)
            for contacts in contact:
                line=f"{contacts["name"]},{contacts["email"]},{contacts["phone_num"]},{contacts["address"]}\n"
                file.write(line)    
    