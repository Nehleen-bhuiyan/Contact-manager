contact=[]
import add_contact
import view_contact
import remove_contact
import search_contact


print("Welcome to contact book management system")
while True:
    print("Choose an option:")
    print("0.Exit")
    print("1.Add contact")
    print("2.View contact")
    print("3.Remove contact")
    print("4.Search contact")
    choice=int(input("Enter your choice:"))
    if choice==0:
        print("Thank you for using contact book management system")
        break
    elif choice==1:
        add_contact.add_contact(contact)
    elif choice==2:
        view_contact.view_contact()
    elif choice==3:
        remove_contact.remove_contact(contact)
    elif choice==4:
        search_contact.search_contact()
    else:
        print("Invalid choice")



