import csv
def remove_contact(contact):
    rem_contact=input("Enter name of contact you want to remove:")
    with open("contact.csv","r") as file:
        content=csv.DictReader(file)
        for row in content :
            if row["name"]!=rem_contact:
                contact.append(row)
    with open ("contact.csv","w") as file:
        line ="name,email,phone_num,address\n"
        file.write(line)
        for contacts in contact:
            line=f"{contacts["name"]},{contacts["email"]},{contacts["phone_num"]},{contacts["address"]}\n"
            file.write(line)
                
    print("Contact removed successfully")   
             
        
       