import csv
def view_contact():
    with open("contact.csv","r") as file:

        content =csv.DictReader(file)
        for row in content:
            print(f"Name:{row["name"]} |Email:{row["email"]} |Phone number:{row["phone_num"]} |Address:{row["address"]}")