import csv

from save_contact import save_contact
def add_contact(contact):
    while True:
        try:
            name=input("Enter name of contact:")
            break
        except ValueError:
            print("Enter string data please")
    while True:
        email=input("Enter email of contact:")
        if "@" in email and "." in email:
            break
        else:
            print("Invalid email")
    while True:
        phone_num=input("Enter phone number of contact:")
        with open("contact.csv","r") as file:
            content=csv.DictReader(file)
            for row in content:
                if row["phone_num"]==phone_num:
                    print("Phone number already exists")
                    break
            else:
                if(len(phone_num)==11 and phone_num.isdigit()):
                    break   
                else:
                    print("Invalid phone number")
    address=input("Enter address of contact:")
    data={
        "name":name,
        "email":email,
        "phone_num":phone_num,
        "address":address
    }   
    contact.append(data)
    save_contact(contact)
    print("Contact added successfully")

    return contact

